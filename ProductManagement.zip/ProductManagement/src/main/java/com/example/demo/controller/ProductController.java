package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createProduct(@RequestBody Product product) {
        Product createdProduct = productRepository.save(product);
        Map<String, Object> response = new HashMap<>();
        response.put("success", 1);
        response.put("request_params", product);
        response.put("message", "Product created successfully!");
        Map<String, Long> data = new HashMap<>();
        data.put("prod_id", createdProduct.getProdId());
        response.put("data", data);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping("/get")
    public ResponseEntity<Map<String, Object>> getProducts(@RequestParam("prod_name") String prodName) {
        List<Product> products = productRepository.findByProdNameContainingIgnoreCase(prodName);
        Map<String, Object> response = new HashMap<>();
        response.put("success", 1);
        response.put("data", products);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
